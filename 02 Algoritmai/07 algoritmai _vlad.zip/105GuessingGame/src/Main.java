
public class Main {
    public static void main(String[] args) {
        // test your program here
        GuessingGame game = new GuessingGame();
        game.play(1,100);
        
//        System.out.println(game.average(3, 4));
//        System.out.println(game.average(6, 12));
    }    
}

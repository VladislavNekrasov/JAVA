import java.sql.Array;
import java.util.Arrays;

public class Sorting {
	public Sorting() {

	}

	public static int smallest(int[] array) {

		int min = array[0];
		for (int i = 0; i < array.length; i++) {

			if (array[i] < min) {
				min = array[i];
			}
		}
		return min;
	}

//104.2
	public static int indexOfTheSmallest(int[] array) {
		int index = 0;
		for (int i = 0; i < array.length; i++)
			if (array[i] == smallest(array))
				index = i;

		return index;
	}

//	104.3
	public static int indexOfTheSmallestStartingFrom(int[] array, int index) {
		int minIndex = index;
		for (int i = index; i < array.length; i++) {
			if (array[i] < array[minIndex]) {
				minIndex = i;
			}
		}
		return minIndex;

	}

//	104.4
	public static void swap(int[] array, int index1, int index2) {
		int valuefirst = array[index1];
		int valuesecond = array[index2];

		array[index2] = valuefirst;
		array[index1] = valuesecond;
	}

	public static void selectionsort(int[] array) {
//		for(int i = 0; i<array.length-1;i++) {
//			int min =i;
//			for(int j = i+1; j<array.length-1;j++) {
//				if(array[min] < array[j]) {
//					min = j;
//				}
//			}
//			int temp = array[i];
//			array[i]= array[min];
//			array[min] = temp;
//		}
		for (int i = 0; i < array.length; i++) {
			System.out.println(Arrays.toString(array));
			int indexsmall = indexOfTheSmallestStartingFrom(array, i);
			swap(array, i, indexsmall);

		}
	}
}

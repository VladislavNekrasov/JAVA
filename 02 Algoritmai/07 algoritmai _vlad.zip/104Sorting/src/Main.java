import java.util.Arrays;

public class Main {
	public static void main(String[] args) {
//		int[] array = { 6, 5, 8, 7, 11 };
		Sorting sort = new Sorting();
//		
//
//		System.out.println(sort.smallest(array));
//		System.out.println(sort.indexOfTheSmallest(array));
//
//		
//		int[] values = { -1, 6, 9, 8, 12 };
//		System.out.println(sort.indexOfTheSmallestStartingFrom(values,1));
//		System.out.println(sort.indexOfTheSmallestStartingFrom(values,2));
//		System.out.println(sort.indexOfTheSmallestStartingFrom(values,4));
//
//		
//		int[] valuesforswaping = {3,2,5,4,8};
//		System.out.println(valuesforswaping);
//		System.out.println( Arrays.toString(valuesforswaping));
//		
//		sort.swap(valuesforswaping, 1, 0);
//		System.out.println( Arrays.toString(valuesforswaping));
//		
//		sort.swap(valuesforswaping, 0, 3);
//		System.out.println( Arrays.toString(valuesforswaping));
		
		int[] values = {8,3,7,9,1,2,4};
		sort.selectionsort(values);
		
	}

	
}

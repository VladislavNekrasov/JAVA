
public class StarSign {

	public static void main(String[] args) {

		
		printStars(3);
		System.out.println("\n---"); // printing --- between the shapes

		
		printSquare(4);
		System.out.println("\n---"); // printing --- between the shapes

		
		printRectangle(5, 6);
		System.out.println("\n---"); // printing --- between the shapes
		
		printTriangle(5);
	}
////////////////////////////////////////////////////////////////////////
	public static void printStars(int number) {
		for(int i =0; i<number; i++){
	        System.out.print("*");}
	    }
	
///////////////////////////////////////////////////////////////////////////
	public static void printSquare(int size) {
		int temp = 1;
	    while(temp<=size){
	        printStars(size);
	        System.out.println();
	        temp++;}
	         }
//////////////////////////////////////////////////////////////////////////////
	public static void printRectangle(int width, int height) {
		 int temp = 0;
		    while(temp<=width){
		        printStars(width);
		        System.out.println();
		        temp++;
		        if(temp==height){
		            break;}
		    }
		}
/////////////////////////////////////////////////////////////////////////////	
	public static void printTriangle(int size) {
	    for(int i=0; i<=size; i++){
	        printStars(i);
	        System.out.println();
	    }
}
}

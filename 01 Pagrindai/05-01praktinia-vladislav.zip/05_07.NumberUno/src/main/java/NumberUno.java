
import java.util.Scanner;

public class NumberUno {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        numberUno();
    }

public static int numberUno() {
	int Uno =1;
	System.out.println(Uno);
	return Uno;
	
} 
}
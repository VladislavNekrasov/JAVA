
import java.util.Scanner;

public class Word {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        String du = word();

    }

public static String word() {
	String ehh = "uzteks";
	return ehh;
	
}
}

import java.util.Scanner;

public class Reprint {

    public static void main(String[] args) {
        // ask the user for how many times should the text be printed
        // then call the printText-method multiple times with a while-loop
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("How many times?");
        int number = scanner.nextInt();
        
        int count = 1;
        
        while (count<=number) {
        	count++;
            printText();
        }
        	
        
        
        
    }
    

    public static void printText() {
    	System.out.println("in a hole in the ground there lived a method");

    }
}

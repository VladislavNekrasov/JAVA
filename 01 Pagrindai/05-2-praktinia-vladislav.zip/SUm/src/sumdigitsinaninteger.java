
public class sumdigitsinaninteger {
public static void main(String[] args) {
	
	System.out.println(sumDigits(234));
	
	
	
}
public static int sumDigits(long n) {
	long sum = 0;
	
	while(n>0) {
		long remainder = n % 10;
		sum = sum + remainder;
		n = n /10;
		 
	} return (int) sum;
	

	
}
}

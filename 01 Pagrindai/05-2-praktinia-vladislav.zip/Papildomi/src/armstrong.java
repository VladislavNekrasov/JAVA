import java.util.Scanner;

public class armstrong {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
//---------------------------------------------------------------------
		
		System.out.println("Enter start Integer");
		int start = scan.nextInt();
		System.out.println("Enter end integer");
		int end = scan.nextInt();
		
		int arm;
		System.out.println("Armstrong numbers between "+ start +" to "+ end);
		while (start < end) {
			arm = armstrongOrNot(start);
			if (arm == start)
				System.out.println(start);
			start++;
		}
	}

	static int armstrongOrNot(int num) {
		int x, a = 0;
		while (num != 0) {
			x = num % 10;
			a = a + (x * x * x);
			num /= 10;
		}
		return a;
	}
}
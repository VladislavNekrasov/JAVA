import java.sql.Array;

public class Arrays {
	public static void main(String[] args) {

	}

	public static int[] generateRandomArray(int size, int min, int max) {
		int[] numbers = new int[size];

		for (int idx = 0; idx < numbers.length; idx++) {
			int b = (int) (Math.random() * (max - min + 1) + min);
			numbers[idx] = b;
		}
		return numbers;
	}

	public static void printArray(int[] array) {
		for (int n : array) {
			System.out.print(n + " ");
		}

	}

	public static int maziausiasElement(int[] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] > array[j]) {
					int temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
		return array[0];

	}

	public static int maziausiasIndex(int[] a) {
		int index = 0;
		int min = a[index];

		for (int i = 1; i < a.length; i++) {
			if (a[i] <= min) {
				min = a[i];
				index = i;
			}
		}
		return index;
	}

	public static int DalinasiIsTriju(int[] a) {
		int count = 0;
		for (int e : a) {
			if (e % 3 == 0) {
				count++;
			}
		}
		return count;
	}

	public static void swapRandomElements(int[] a) {
		int max = a.length - 1;
		int min = a[0];
		int c = (int) (Math.random() * (max - min + 1) + min);
		int b = (int) (Math.random() * (max - min + 1) + min);
		int temp = a[b];
		a[b] = a[c];
		a[c] = temp;

	}
	public static int[] removeRandomElement(int[]array) {
		int max = array.length - 1;
		int min = array[0];
		int remove = (int) (Math.random() * (max - min + 1) + min);
		int[] arr_new = new int[array.length-1];
		for(int i =0, k=0; i<array.length; i++) {
			if(array[i]!=remove) {
				arr_new[k]=array[i];
				k++;
			}
			
		}
		return arr_new;
	}
	public static int[] PridetiXpriesE(int[]array) {
		int max = array.length - 1;
		int min = array[0];
		int rindex = (int) (Math.random() * (max - min + 1) + min);
		int relem = (int) (Math.random() * (max - min + 1) + min);
		
		int[] arr_new = new int[array.length];
		
		 int prevValue = relem;

		    // Shift all elements to the right, starting at rindex
		    for (int i = rindex; i < array.length; i++) {
		        int tmp = prevValue;
		        prevValue = array[i];
		        array[i] = tmp;
		    }
		    return array;
		
		
		
	}
	public static void ApverstiMasyva(int[] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] < array[j]) {
					int temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
		
}
}

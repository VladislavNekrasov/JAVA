package triangle;

public class triangle {
public static void main(String[] args) {
	int edge1 = 4;
	int edge2 = 8;
	int edge3 = 8;
	
	int perimeter = edge1 + edge2 + edge3;
	
	if(edge1+edge2>edge3 && edge2+edge3>edge1 && edge1+edge3>edge2) {
		System.out.println("Input is valid" + " Perimetre: " + perimeter);
	} else {
		System.out.println("Input is Invalid");
	
	} 
		
}
}

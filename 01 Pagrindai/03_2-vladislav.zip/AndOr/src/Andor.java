import java.util.Scanner;

public class Andor {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter an Integer:");
	int userint = scan.nextInt();
	System.out.println("Is " + userint + " Divisible by 4 and 5? " + (userint%4==0 && userint%5==0));
	System.out.println("Is " + userint + " Divisible by 4 or 5? " + (userint%4==0 | userint%5==0));
	System.out.println("Is " + userint + " Divisible by 4 or 5 but not both? " + (userint%4==0 || userint%5==0));
		
	
}
}

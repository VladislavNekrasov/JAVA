import java.util.Scanner;

public class SortThreeIntegers {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter first digit");
	int num1 = scan.nextInt();
	System.out.println("Enter Second digit");
	int num2 = scan.nextInt();
	System.out.println("Enter Third digit");
	int num3 = scan.nextInt();
	
    int temp;

    if (num2 < num1) {
      temp = num1;
      num1 = num2;
      num2 = temp;
    }

    if (num3 < num2) {
      temp = num2;
      num2 = num3;
      num3 = temp;
    }

    if (num2 < num1) {
      temp = num1;
      num1 = num2;
      num2 = temp;
    }

    System.out.println(num3);
    System.out.println(num2);
	System.out.println(num1);

}
}

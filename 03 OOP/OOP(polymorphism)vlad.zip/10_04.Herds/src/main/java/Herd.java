import java.util.ArrayList;

public class Herd implements Movable {
	private ArrayList<Movable> obj;

	public Herd() {
		this.obj = new ArrayList<>();
	}

	public void addToHerd(Movable movable) {
		obj.add(movable);
	}

	@Override
	public void move(int dx, int dy) {
		// TODO Auto-generated method stub
		for (Movable movable : obj) {
			movable.move(dx, dy);
		}
	}

	@Override
	public String toString() {
		String text = "";
		for (Movable item : obj) {
			text += item.toString() + "\n";
		}
		return text;

	}

}

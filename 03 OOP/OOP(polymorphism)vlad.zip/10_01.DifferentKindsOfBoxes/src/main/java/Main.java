

public class Main {

    public static void main(String[] args) {
        BoxWithMaxWeight coffeeBox = new BoxWithMaxWeight(10);
        coffeeBox.add(new Item("Saludo", 5));
        coffeeBox.add(new Item("pirkka", 5));
        coffeeBox.add(new Item("kopi luwak", 5));
        System.out.println(coffeeBox.isInBox(new Item("Saludo")));
        System.out.println(coffeeBox.isInBox(new Item("pirkka")));
        System.out.println(coffeeBox.isInBox(new Item("kopi luwak")));
        
        OneItemBox box = new OneItemBox();
        box.add(new Item("Saludo", 5));
        box.add(new Item("pirkka", 5));
        System.out.println(box.isInBox(new Item("Saludo")));
        System.out.println(box.isInBox(new Item("pirkka")));
        
        MisplacingBox Mbox = new MisplacingBox();
        Mbox.add(new Item("Saludo", 5));
        Mbox.add(new Item("pirkka", 5));
        System.out.println(Mbox.isInBox(new Item("Saludo")));
        System.out.println(Mbox.isInBox(new Item("pirkka")));
        
    }
}

import java.util.ArrayList;

public class Box implements Packable {
	private int capacity;
	private ArrayList<Packable> packed;

	public Box(int capacity) {
		this.packed = new ArrayList<>();
		this.capacity = capacity;
	}
	
	public void add(Packable item) {
		if(this.weight() + item.weight()<= this.capacity)
			this.packed.add(item);
	}

	@Override
	public double weight() {
		// TODO Auto-generated method stub
		double weight = 0;
		for (Packable item : packed) {
			weight += item.weight();
		}
		return weight;
	}
	@Override
	public String toString() {
		return "Box: " + this.packed.size() + " items, total weight " + this.weight() + " kg";
	}
	

}

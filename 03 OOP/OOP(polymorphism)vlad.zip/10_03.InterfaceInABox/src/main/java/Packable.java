
public interface Packable {
	double weight();

}

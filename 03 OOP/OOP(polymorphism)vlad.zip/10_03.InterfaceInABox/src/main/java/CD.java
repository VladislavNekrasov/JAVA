
public class CD implements Packable{
	private String artist;
	private String title;
	private int publicationyear;
	private final double weight;
	
	public CD(String artist, String title, int publicationyear) {
		this.artist = artist;
		this.title = title;
		this.publicationyear = publicationyear;
		this.weight = 0.1;
	}

	@Override
	public double weight() {
		// TODO Auto-generated method stub
		return weight;
	}

	@Override
	public String toString() {
		return artist + ": " + title + " (" + publicationyear + ")";
	}
	

}

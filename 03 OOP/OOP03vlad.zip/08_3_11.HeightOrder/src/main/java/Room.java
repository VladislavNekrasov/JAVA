import java.util.ArrayList;

public class Room {
	private ArrayList<Person> room;
	
	public Room() {
		this.room = new ArrayList<>();
	}
	
	public void add(Person person) {
		this.room.add(person);
	}
	
	public boolean isEmpty() {
		return this.room.isEmpty();
	}
	
	public ArrayList<Person> getPersons(){
		return room;
	}
	public Person shortest() {
		if(this.room.isEmpty()) {
			return null;
		}

	    Person shortest = room.get(1);
	    for (Person person : room) {
	        shortest = shortest.getHeight() < person.getHeight() ? shortest : person;
	    }
	    return shortest;
	}
}

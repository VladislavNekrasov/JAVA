
public class Main {

    public static void main(String[] args) {
        Room room = new Room();
        System.out.println("Empty room? " + room.isEmpty());
        room.add(new Person("Lea", 183));
        room.add(new Person("kenya", 182));
        room.add(new Person("auli", 186));
        room.add(new Person("nina", 172));
        room.add(new Person("terhi", 185));
        System.out.println("Empty room? " + room.isEmpty());
        
        System.out.println("");
        for (Person person : room.getPersons()) {
        	System.out.println(person);
        }
        
        System.out.println("");
        System.out.println("Shortest: " + room.shortest());
        
        for(Person person : room.getPersons()) {
        	System.out.println(person);
        }
    }
}


public class Main {

	public static void main(String[] args) {
		Gift book = new Gift("harrypotter", 2);

		System.out.println("gifts name: " + book.getName());
		System.out.println("gifts weight: " + book.getWeight());
		System.out.println("gift: " + book);

	}
}


public class Main {

    public static void main(String[] args) {

        Message mess = new Message("donald", "aosjgpofdkgpldfjvcmvbnxmcnslkjgeueurhteorterjtetjhgdog");
        MessagingService msngr = new MessagingService();
        
        msngr.add(mess);
        System.out.println(msngr.getMessages());
    }
}

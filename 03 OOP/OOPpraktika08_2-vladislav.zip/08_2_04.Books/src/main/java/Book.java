
public class Book {
	private String title;
	private int pages;
	private int date;

	public Book(String title, int pages, int date) {
		this.title = title;
		this.pages = pages;
		this.date = date;
	}

	public String getTitle(String title) {
		return title;
	}

	public int getPages(int pages) {
		return pages;
	}

	public int getDate(int date) {
		return date;
	}

	public String toString(String displaywhat) {
		if (displaywhat.equalsIgnoreCase("everything")) {
			return this.title + ", " + this.pages + "pages, " + this.date;
		} else {
			if (displaywhat.equalsIgnoreCase("name")) {
				return this.title;
			}
			return "";
		}
	}
}

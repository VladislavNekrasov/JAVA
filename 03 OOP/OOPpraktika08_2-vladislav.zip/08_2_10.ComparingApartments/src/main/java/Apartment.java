
public class Apartment {

    private int rooms;
    private int squares;
    private int princePerSquare;

    public Apartment(int rooms, int squares, int pricePerSquare) {
        this.rooms = rooms;
        this.squares = squares;
        this.princePerSquare = pricePerSquare;
    }
    public boolean largerThan(Apartment compared) {
    	if (this.squares>compared.squares) {
    		return true;
    	}
    	return false;
    }
    public int priceDifference(Apartment compared) {
    	int apart = this.squares * this.princePerSquare;
    	int apartcomp = compared.squares * compared.princePerSquare;
    	return Math.max(apart, apartcomp) - Math.min(apart, apartcomp);
    	
    }
    public boolean moreExpensiveThan(Apartment compared) {
    	int apart = this.squares * this.princePerSquare;
    	int apartcomp = compared.squares * compared.princePerSquare;
    	if (apart>apartcomp) {
    		return true;
    	}
    	return false;
    }

}


public class MainProgram {

    public static void main(String[] args) {
        // Test your counter here
    	Counter counter = new Counter(10);
    	
//    	Increase by 1
    	counter.increase();
    	System.out.println(counter.value());
//    	Decrease by 1
    	counter.decrease();
    	System.out.println(counter.value());
//    	overloaded Increase by 10
    	counter.increase(10);
    	System.out.println(counter.value());
//    	overloaded decrease by 5
    	counter.decrease(5);
    	System.out.println(counter.value());
//    	overloaded Increase by negative value
    	counter.increase(-100);
    	System.out.println(counter.value());
//    	overloaded decrease by negative value
    	counter.decrease(-500);
    	System.out.println(counter.value());
    }
}

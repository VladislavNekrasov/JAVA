
public class Main {

    public static void main(String[] args) {
        HealthStation Hospital = new HealthStation();
        
//        WEIGHT
        Person Ethan = new Person("Ethan", 12, 100, 46);
        Person Herald = new Person("Herald", 42, 189, 84);
//        System.out.println(Ethan.getName() + " weight: "+ Hospital.weigh(Ethan)+ " Kg");
//        System.out.println(Herald.getName() + " weight: "+ Hospital.weigh(Herald)+ " Kg");
//        
////        FEED
//        Hospital.feed(Ethan);
//        Hospital.feed(Ethan);
//        Hospital.feed(Ethan);
//        System.out.println(Ethan.getName() + " weight: "+ Hospital.weigh(Ethan)+ " Kg");
        
//        WEIGHINGS
//        System.out.println("weighings performed: " + Hospital.weighings());
//        Hospital.weigh(Ethan);
//        Hospital.weigh(Ethan);
//        System.out.println("weighings performed: " + Hospital.weighings());
//        Hospital.weigh(Ethan);
//        Hospital.weigh(Ethan);
//        Hospital.weigh(Ethan);
//        System.out.println("weighings performed: " + Hospital.weighings());
//        Hospital.weigh(Ethan);
//        Hospital.weigh(Ethan);
//        Hospital.weigh(Ethan);
//        Hospital.weigh(Ethan);
//        Hospital.weigh(Ethan);
//        System.out.println("weighings performed: " + Hospital.weighings());
        
        
    }
}

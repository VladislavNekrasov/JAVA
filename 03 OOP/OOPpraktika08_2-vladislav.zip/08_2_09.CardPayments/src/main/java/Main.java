
public class Main {

	public static void main(String[] args) {
		PaymentCard petesCard = new PaymentCard(10);
//       1 PART-------------------------------------------------------------
//       System.out.println("money "+ petesCard.balance());
//       boolean wasSuccessful = petesCard.takeMoney(8);
//       System.out.println("successfully withdrew: "+ wasSuccessful);
//       System.out.println("money "+ petesCard.balance());
//       
//       wasSuccessful = petesCard.takeMoney(4);
//       System.out.println("successfully withdrew: "+ wasSuccessful);
//       System.out.println("money "+ petesCard.balance());

//       2 PART------------------------------------------------------------
//       PaymentTerminal unicafe = new PaymentTerminal();
//       
//       double change = unicafe.eatAffordably(10);
//       System.out.println("remaining change " + change);
//       
//       change = unicafe.eatAffordably(5);
//       System.out.println("remaining change " + change);
//       
//       change = unicafe.eatHeartily(4.3);
//       System.out.println("remaining change " + change);
//       
//       System.out.println(unicafe);

//       3 PART---------------------------------------------------------------
//		PaymentTerminal unicafe = new PaymentTerminal();
//
//		double change = unicafe.eatAffordably(10);
//		System.out.println("remaining change " + change);
//		
//		PaymentCard annesCard = new PaymentCard(7);
//		
//		boolean wasSuccessful = unicafe.eatHeartily(annesCard);
//		System.out.println("There was enough money: "+ wasSuccessful);
//		wasSuccessful = unicafe.eatHeartily(annesCard);
//		System.out.println("There was enough money: "+ wasSuccessful);
//		wasSuccessful = unicafe.eatAffordably(annesCard);
//		System.out.println("There was enough money: "+ wasSuccessful);
//		System.out.println(unicafe);
//		
//		PART 4 ----------------------------------------------------------------------
		PaymentTerminal unicafe = new PaymentTerminal();
		System.out.println(unicafe);
		
		PaymentCard annesCard = new PaymentCard(2);
		System.out.println("amount of money on the card is "+ annesCard.balance());
		
		boolean wasSuccessful = unicafe.eatHeartily(annesCard);
		System.out.println("There was enough money: "+ wasSuccessful);
		
		unicafe.addMoneyToCard(annesCard, 100);
		wasSuccessful = unicafe.eatHeartily(annesCard);
		System.out.println("There was enough money: "+ wasSuccessful);
		
		System.out.println("amount of money on the card is "+ annesCard.balance());
		
		System.out.println(unicafe);

}}

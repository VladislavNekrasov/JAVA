package uml_02.ThePlayerAndTheBot;

public class Player {
	private String name;
	
	public void pritnName() {
		
	}
}

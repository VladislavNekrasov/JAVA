package uml_02.ThePlayerAndTheBot;

public class Bot extends Player{
	
	public Bot() {
		
	}
	
	public void play() {
		
	}
	public void addMove(String move) {
		
	}

}

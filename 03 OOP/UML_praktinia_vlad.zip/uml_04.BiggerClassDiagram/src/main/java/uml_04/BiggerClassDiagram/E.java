package uml_04.BiggerClassDiagram;

import java.util.ArrayList;

public class E extends C{
	ArrayList<C> c; 
}

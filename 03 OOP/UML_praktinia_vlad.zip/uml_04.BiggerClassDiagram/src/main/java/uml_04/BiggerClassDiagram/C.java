package uml_04.BiggerClassDiagram;

public class C extends B implements IC{
	
	

}

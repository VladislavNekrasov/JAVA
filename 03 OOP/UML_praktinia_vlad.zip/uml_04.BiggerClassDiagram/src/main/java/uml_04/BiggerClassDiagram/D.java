package uml_04.BiggerClassDiagram;

public class D {
	IA ia;
}

package uml_04.BiggerClassDiagram;

public class B extends A implements IB{

}

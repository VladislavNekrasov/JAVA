package uml_04.BiggerClassDiagram;

public class A implements IA{

}

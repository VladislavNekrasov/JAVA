package uml_04.BiggerClassDiagram;

public interface IA {
	public final String d= "d";

}

package uml_04.BiggerClassDiagram;

public interface IB {

}

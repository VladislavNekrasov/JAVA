package uml_01.StudentAndUniversity;

public class Student {
	private int studentID;
	private String name;
	private University university;
	
	public Student() {
		
	}
}

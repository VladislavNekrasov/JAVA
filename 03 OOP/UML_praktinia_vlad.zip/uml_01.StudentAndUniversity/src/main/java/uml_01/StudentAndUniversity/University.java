package uml_01.StudentAndUniversity;

import java.util.ArrayList;

public class University {
	private String name;
	
	private ArrayList<Student> students;

	public University() {
		// TODO Auto-generated constructor stub
	}
}

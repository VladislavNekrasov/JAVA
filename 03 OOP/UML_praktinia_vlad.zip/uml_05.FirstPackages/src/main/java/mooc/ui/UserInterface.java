package mooc.ui;

public interface UserInterface {
void update();
}

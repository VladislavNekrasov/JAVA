
import java.util.Scanner;

public class OnlyPositives {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        
        int value;
        
        do {
        	System.out.println("Give a number:");
        	value = scanner.nextInt();
        	
        	if(value<0) {
        		System.out.println("Unsuitable number");
        	} else {
        		int answer = value * value;
        		System.out.println(answer);
        	}
        } while(value!=0);
        	
        

    }
}

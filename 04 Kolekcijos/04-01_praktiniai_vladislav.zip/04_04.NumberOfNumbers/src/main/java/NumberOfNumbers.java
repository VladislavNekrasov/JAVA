
import java.util.Scanner;

public class NumberOfNumbers {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int value=1;
        int count=0;
        
        System.out.println("Give a number:");
    	value = scanner.nextInt();
        
    	while(value!=0) {
        	count++;
        	System.out.println("Give a number:");
        	value = scanner.nextInt();
        }
        
        	
    	System.out.println("Number of numbers: " + count);
        
    	

    }
}

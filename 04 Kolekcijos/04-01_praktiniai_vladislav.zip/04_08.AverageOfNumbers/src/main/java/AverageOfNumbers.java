
import java.util.Scanner;

public class AverageOfNumbers {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double value, sum=0.0, count=-1.0;
        
        do {
        	count++;
        	System.out.println("Give a number:");
        	value = scan.nextDouble();
        	sum = sum+value;
        	
        } while (value!=0);
        double avrg = sum / count;
        
        System.out.println("Average of numbers: " + avrg);
        
        
    }
}

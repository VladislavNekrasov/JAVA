
import java.util.Scanner;

public class NumberAndSumOfNumbers {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int value, sum=0, count=-1;
        
        do {
        	++count;
        	System.out.println("Give a number:");
            value = scanner.nextInt();
            sum=sum+value;
            
            
        } while(value!=0);
        System.out.println("Number of numbers: " + count);
        System.out.println("The sum of the numbers is: "+sum);
        
        
        
    }
}


public class Multiplicationtable {
public static void main(String[] args) {
	
	for(int line1=1; line1<=9; line1++) {
		
		for(int line2=1; line2<=9; line2++) {
			System.out.print((line1*line2) + " ");
			
		}
		System.out.println();
			
	}
	
}
}

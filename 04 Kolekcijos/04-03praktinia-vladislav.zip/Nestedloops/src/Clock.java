
public class Clock {
public static void main(String[] args) {
	
	for(int hrs= 0; hrs<=23; hrs++) {
		for(int min=0; min<=59; min++)
			System.out.printf("%02d : %02d%n", hrs, min);
			
			
		
	}
	
}
}

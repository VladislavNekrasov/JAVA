
public class WEEKANDDAYS {
public static void main(String[] args) {
	
	
	for(int i=1; i<=4; i++) {
		System.out.println("Week " + i);
		for(int d =1; d<=7; d++) {
			System.out.println("Day " + d);
		}
	}
}
}

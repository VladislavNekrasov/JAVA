
public class Box<T extends Comparable<T>> {

	private T item1;
	private T item2;
	private boolean islocked;
	

	public Box(T item1, T item2) {
		this.item1 = item1;
		this.item2 = item2;
		this.islocked = false;
	}
	 

	public boolean islocked() {
		return islocked;
	}

	public void Lock() {
		this.islocked = true;
	}
	public void unlock() {
		this.islocked = false;
	}


	public T getItem1() {
		if(!islocked()) {
			return item1;
		}
		throw new RuntimeException("The box is locked");
	}

	public T getItem2() {
		if(!islocked()) {
			return item2;
		}
		throw new RuntimeException("The box is locked");
	}

	@Override
	public String toString() {
		if(!islocked()) {
			String item1 = this.item1 != null ? this.item1.toString() : ""; 
			String item2 = this.item2 != null ? this.item2.toString() : ""; 
			
			return item1 + " : " + item2;
		}
		throw new RuntimeException("The box is locked");
		
	}

	public T getSmaller() {
		if(!islocked()) {
			if (item1.compareTo(item2) < 0) {
			return item1;
		}

		return item2;
		}
		return null;
		

	}
}

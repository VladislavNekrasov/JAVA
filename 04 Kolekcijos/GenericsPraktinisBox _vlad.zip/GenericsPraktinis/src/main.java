import java.util.ArrayList;
import java.util.List;

public class main {
	public static void main(String[] args) {
		
		Box<String> twoNames = new Box<>("John","Jane");
		System.out.printf("twoNames+%s.%n",twoNames);
		String name1 = twoNames.getItem1();
		String name2 = twoNames.getItem2();
		
		Box<Integer> twoNums = new Box<>(8,5);
		System.out.printf("twoNums+%s.%n",twoNums);
		Integer num1 = twoNums.getItem1();
		Integer num2 = twoNums.getItem2();
		
		twoNums.Lock();
		System.out.println(twoNums);

	}
	 static <T> T lastElementList(List<T> list){
		return list.get(list.size()-1);
		
	}
	 static <T> T lastElementArray(T[]a) {
		 return a[a.length-1];
	 }
}

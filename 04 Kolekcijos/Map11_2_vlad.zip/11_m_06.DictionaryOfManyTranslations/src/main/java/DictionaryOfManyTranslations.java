import java.util.ArrayList;
import java.util.HashMap;

public class DictionaryOfManyTranslations {
	private HashMap<String, ArrayList<String>> dictionary;
	

	public DictionaryOfManyTranslations() {
		this.dictionary = new HashMap<>();
		

	}

	public void add(String word, String translation) {
		if(dictionary.containsKey(word)) {
			ArrayList<String> list = dictionary.get(word);
			for(String E : list) {
				if(E.toLowerCase().equalsIgnoreCase(translation)) {
					return;
				}
			}
			list.add(translation);
		} else {
			dictionary.put(word, new ArrayList<String>() {
				{
					add(translation);
				}
			});
		}

	}

	public ArrayList<String> translate(String word) {
		if (dictionary.containsKey(word)) {
			return dictionary.get(word);
		}

		return new ArrayList<>();
	}



	public void remove(String word) {
		dictionary.remove(word);

	}
}

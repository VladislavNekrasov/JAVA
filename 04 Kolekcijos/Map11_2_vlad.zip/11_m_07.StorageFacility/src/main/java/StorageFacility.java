import java.util.ArrayList;
import java.util.HashMap;

public class StorageFacility {
	private HashMap<String, ArrayList<String>> storage;

	public StorageFacility() {
		this.storage = new HashMap<>();
	}

	public void add(String unit, String item) {
		ArrayList<String> contents = storage.get(unit);
		if (storage.containsKey(unit)) {
//			
			contents.add(item);
		} else {
			storage.put(unit, new ArrayList<String>() {
				{
					add(item);
				}
			});
		}
	}

	public ArrayList<String> contents(String storageUnit) {
		if (storage.containsKey(storageUnit)) {
			return storage.get(storageUnit);
		}

		return new ArrayList<>();
	}

	public void remove(String storageUnit, String item) {
		if (storage.containsKey(storageUnit)) {
			ArrayList<String> contents = storage.get(storageUnit);
			if (contents.contains(item)) {
				for (String entry : contents) {
					if (entry.equalsIgnoreCase(item)) {
						contents.remove(entry);

						if (contents.size() == 0) {
							storage.remove(storageUnit);
						}
						return;
					}
				}

			}
		}
	}

	public ArrayList<String> storageUnits() {
		return new ArrayList<String>(storage.keySet());
	}
}

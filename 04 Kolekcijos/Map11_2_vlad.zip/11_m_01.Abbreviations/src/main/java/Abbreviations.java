import java.util.HashMap;
import java.util.Map;

public class Abbreviations {
	private Map<String, String> abbr;
	
	public Abbreviations() {
		abbr = new HashMap<String, String>();
	}
	public void addAbbreviation (String Abbreviation,String explanation) {
	abbr.put(Abbreviation, explanation);
		
	}
	public boolean hasAbbreviation(String Abbreviation) {
		if(abbr.containsKey(Abbreviation)) {
			return true;
		}
		return false;
	}
	public String findExplanationFor(String Abbreviation) {
		return abbr.get(Abbreviation);
	}
}

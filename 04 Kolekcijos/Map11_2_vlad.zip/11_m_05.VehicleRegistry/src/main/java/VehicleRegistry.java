import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class VehicleRegistry {
	
	private HashMap<LicensePlate, String> registry;

	public VehicleRegistry() {
		registry = new HashMap<>();
	}

	public boolean add(LicensePlate licensePlate, String owner) {
		if (registry.containsKey(licensePlate)) {
			return false;
		} else {
			registry.putIfAbsent(licensePlate, owner);
			return true;
		}

	}

	public String get(LicensePlate licensePlate) {
		return registry.getOrDefault(licensePlate, null);
	}

	public boolean remove(LicensePlate licensePlate) {
		if (registry.containsKey(licensePlate)) {
			registry.remove(licensePlate);
			return !registry.containsKey(licensePlate) ? true : false;
		} else {
			return false;
		}
			
		}

	public void printLicensePlates() {
		for (Map.Entry<LicensePlate, String> car : registry.entrySet()) {
			System.out.println(car.getKey());
		}
	}
	public void printOwners() {
		HashSet<String> owners = new HashSet<>();
		
		for(Map.Entry<LicensePlate, String> entry : registry.entrySet()) {
			owners.add(entry.getValue());
		}
		owners.forEach((k) -> System.out.println((k+"\n")));
			
	}
			
}

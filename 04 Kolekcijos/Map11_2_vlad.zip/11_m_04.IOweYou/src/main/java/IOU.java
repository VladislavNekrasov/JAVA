import java.util.HashMap;
import java.util.Map;

public class IOU {
	private String toWhom;
	private double amount;
	private Map<String, Double> people;

	public IOU() {
		people = new HashMap<String, Double>();

	}

	public void setSum(String toWhom, double amount) {
		people.put(toWhom, amount);
	}

	public double howMuchDoIOweTo(String toWhom) {
		return people.get(toWhom);
	}
}

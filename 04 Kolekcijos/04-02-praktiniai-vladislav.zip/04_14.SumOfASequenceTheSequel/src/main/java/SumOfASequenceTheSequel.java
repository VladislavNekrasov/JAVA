
import java.util.Scanner;

public class SumOfASequenceTheSequel {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int sum = 0;
        
        System.out.println("First number?");        
        int value2 = scanner.nextInt();
        
        System.out.println("Last number?");
        int value = scanner.nextInt();
        
        for(int i = value2; i <=value; i++) {
        	sum = sum + i;
        }
        System.out.println("The sum is; "+ sum);

    }
}

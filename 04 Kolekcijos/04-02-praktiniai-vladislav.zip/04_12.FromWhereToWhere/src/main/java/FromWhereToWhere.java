
import java.util.Scanner;

public class FromWhereToWhere {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        System.out.println("Where to?");
        int value = scanner.nextInt();
        System.out.println("where from?");
        
        int value2 = scanner.nextInt();
        for(int i = value2; i <=value; i++) {
        	System.out.println(i);
        }
    }
}

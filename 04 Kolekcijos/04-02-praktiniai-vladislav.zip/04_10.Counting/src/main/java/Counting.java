
import java.util.Scanner;

public class Counting {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("enter a number:");
        int value = scanner.nextInt();
        
        for(int i=0; i<=value; i++) {
        	System.out.println(i);
        }

    }
}

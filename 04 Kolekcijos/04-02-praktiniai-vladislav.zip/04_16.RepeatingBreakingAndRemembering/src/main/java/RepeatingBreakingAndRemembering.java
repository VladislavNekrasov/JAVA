
import java.util.Scanner;

public class RepeatingBreakingAndRemembering {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int number;
        double sum = 0.0;
        int count = 0;
        double average=0;
        int countodd= 0;
        int counteven=0;
        
        do {
        	System.out.println("give a number");
            number = scanner.nextInt();
            if(number==-1) {
            	System.out.println("Thx bye");
            	break;
            }
            if(number%2==1) {
            	countodd++;
            } else {
            	counteven++;
            }
            
            count++;
            sum = sum + number;
            average = sum / count;
        } while (number>0);
        System.out.println("Numbers: " + count);
        System.out.println("Sum: " + sum);
        System.out.println("Average: " + average);
        System.out.println("Even: " + counteven);
        System.out.println("Odd: " + countodd);

    }
}


import java.util.Scanner;

public class CountingToHundred {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("enter a number");
        int value = scanner.nextInt();
        
        for(int i = value; i<=100; i++) {
        	System.out.println(i);
        }

    }
}

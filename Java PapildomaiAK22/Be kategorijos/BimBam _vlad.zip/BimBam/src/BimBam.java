
public class BimBam {
	public static void main(String[] args) {
		printBimBam(16);

	}

	public static void printBimBam(int toWhere) {
		int[] bimbam = new int[toWhere];
		int count = 0;
		for(int i = 0; i < bimbam.length; i ++) { 
			count++;
			bimbam[i]= count;
			
		}
		for(int num : bimbam) {
			if(num % 3 ==0) {
				System.out.println("Bim");
			} else if (num % 5 == 0) {
				System.out.println("Bam");
			} else {
				System.out.println(num);
			}
		}
	}
}
